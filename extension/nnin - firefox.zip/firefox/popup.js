function listenForClicks() {
  document.getElementById("generate").onclick = () => {
    var from = document.getElementById("from").value;
    var to = document.getElementById("to").value;
    var nnin = generate(from, to, 1);
    document.getElementById("nnin").value = nnin;
    browser.storage.local.set({
      nnin: nnin
    });

    document.getElementById("fill").removeAttribute("disabled");
    document.getElementById("nnin").select();
  };

  document.getElementById("fill").onclick = () => {
    browser.tabs.query({ active: true, currentWindow: true }).then(tabs => {
      browser.storage.local.get("nnin").then(res => {
        browser.tabs.sendMessage(tabs[0].id, {
          command: "fill",
          nnin: res.nnin
        });
        this.close();
      });
    });
  };
}

browser.tabs.executeScript({ file: "./content.js" }).then(listenForClicks);
